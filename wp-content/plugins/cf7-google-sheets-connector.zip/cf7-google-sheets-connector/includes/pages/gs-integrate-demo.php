<div class="gs-fields gs-second-block">
	<h2><span><?php echo esc_html( __('Google Sheet Connector Pro Demo'));?></span></h2>
	<p>
	  <label><?php echo esc_html( __('URL')); ?></label>
	  https://cf7demo.gsheetconnector.com/wp-admin/            </p>
	<p>
	  <label><?php echo esc_html( __('UserName')); ?></label>
	  demo-repo-user            </p>
	<p>
	  <label><?php echo esc_html( __('Password')); ?></label>
	  !rJaJ@ixux!EIAwiW0FwKkTe            </p>
	<p>
	  <label><?php echo esc_html( __('Sheet URL')); ?></label>
	  <a href="https://docs.google.com/spreadsheets/d/1ooBdX0cgtk155ww9MmdMTw8kDavIy5J1m76VwSrcTSs/" target="_blank" rel="noopener">https://docs.google.com/spreadsheets/d/1ooBdX0cgtk155ww9MmdMTw8kDavIy5J1m76VwSrcTSs/ </a>
	</p>
 </div>