=== Image Slider by NextCode - Photo & Video SLider ===
Contributors: nextcode, pluginjungle
Tags: slider, image slider, video slider, photo slider, WordPress slider
Donate link: https://pluginjungle.com/downloads/image-slider/
Requires at least: 3.5
Stable tag: 1.1.1
Requires PHP: 5.2
Tested up to: 5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Make more impact to your website visitors with your images and videos in Nextcode slider plugin.

== Description ==

>[Slider by NextCode](https://pluginjungle.com/downloads/image-slider/)  |  [Demo](https://pluginjungle.com/nextcode-slider-demo-1/)  |  [Support Forum](https://wordpress.org/support/plugin/baslider/)  |  [Contact US](https://pluginjungle.com/contact/)

Make more impact to your website visitors with your images and videos in Nextcode slider plugin. Slides always make more impression and engage more users, than usual photos and text.

Each famous WordPress website uses Image Slider at least once. It can be  main slider in homepage area, image slides in blog-posts or on other pages. Keep up with your competitors by using Nextcode image slider. Maintain your image slider easily and create stylish posts for your website visitors.

**What are the advantages of Nextcode Image Slider:**

* Our image slider is responsive
* It has the coolest slide effects
* It takes 2 minutes to create an image slider 
* Autoplay option
* Plugin has pause and mute buttons
* Image Slider has even got pagination style effects


If you are a vlogger or you have interesting videos to share with your audience, you will need plugin by Nextcode. It’s easy to use. Just upload your videos on your WordPress media and choose them from settings.

Get the most out of your video slider plugin and use all its capabilities. Enable autoplay option if needed, change background color and slide effects.

The autoplay option is muted first, so your users will need to unmute it to start watching the videos.

Sometimes users prefer to watch images or videos one by one, and we have a pause button which will help them to pause for a while and take their time to see photos in image slider. Users will be able to pause photo slider or video slider at any time if you enable the pause button from settings.

**Upload the Nextcode image slider plugin to your WordPress Dashboard and get the following options:**

* Drag and Drop option
* URL option
* Preview option
* 10 Navigation styles
* 6 slider shadow styles
* Stop on last slide option
* Pause Image slider option
* Responsive slider mode
* Image slider full screen option
* 6 image slider paginations styles
* Autoplay option
* Image slider loading effects


**Responsive Photo Slider**

The responsiveness is a key factor for each wordpress website. Your photo slider should not be an exception, it should fit perfectly to each screen size. That is why we have devoted  a huge section in image slider plugin to its responsiveness.

Image slider size options will not only help you enable its responsive mode, but also choose responsive ratio for each photo slider width and height.


**Full Screen Mode**

Watching videos in small size is not so comfortable, so we have full screen mode which you are able to enable for any image slider or video slider.

Just go and enable full screen mode from size settings.


**Stop Image Slider on Last Slide**

In case you don’t want your users to watch the same photo slider over and over, you can just enable “stop on last slide” option. It’s in image slider general settings.


**Change The Shadow Effects of your Image Slider**

You always have the opportunity to customize your photo slider, even after publishing it on your website. To change the image slider shadow effects , just go to general settings.


**There are 6 shadow effects available in your photo slider plugin.**

You may also change the photo slider pagination effects, make the image slides clickable or dynamic. To find out more options, just download the plugin right away, and upload it to your WordPress directory.

== Screenshots ==

1. Slider