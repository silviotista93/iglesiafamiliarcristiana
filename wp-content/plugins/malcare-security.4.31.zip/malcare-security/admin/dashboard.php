<div>
	<iframe style="width: 100%; height: 1900px; padding-top: 13px;"src="<?=$this->account->authenticatedUrl('/malcare/access')?>">
	</iframe>
</div>