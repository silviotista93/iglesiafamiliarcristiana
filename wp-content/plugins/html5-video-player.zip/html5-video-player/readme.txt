=== Html5 Video Player - mp4 player, Video Player for WordPress  ===
Contributors: abuhayat
Tags: HTML5 video player, plyr, video, video player, mp4 Player 
Donate link: https://gum.co/wpdonate/ 
Requires at least: 5.0
Tested up to: 5.4
Stable tag: 1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Play various video files in wordpress. A Simple, accessible, Easy to Use & fully Customizable video player that works in all devices. 

== Description ==

Play various video files in wordpress. A Simple, accessible, Easy to Use & fully Customizable video player that works in all devices. You can Play / embed a awesome video player in post, page, widget areas as well as templete files. It Has tons of options that fit your video player needs. 


**[Live Demo](https://bit.ly/2WL0Shd "Demo")**

= How to use ? =
Here is a quick tutorial.

https://www.youtube.com/watch?v=dLU67e708fg


= How to use  =
- After install you can see a sidebar menu in the dashboare called "Html5 Video Player "
- Add one or more players from there. 
- You will get Shortcode for every player In the player list.
- Copy Shortcode for playre you wanna publish 
- Past the shortcode in post, page, widget areas To publish them. if you want to publish a player in template file use <?php echo do_shortcode('PLAYER_SHORTCODE') ?>
- Enjoy !

= Gutenberg Block  =
- This plugin add a Gutenberg Block called Html5 Video Player Under Common Block 
- To Add Video player block Go to Post/Page Editor
- Go to Common Block >Select Html5 Video Player
- Select a video Player 
- Publish >  And enjoy !

* For installation help click on Installation Tab

= Features =
* The video player is compact so it does not take a lot of real estate on your webpage
* HTML5 compatible so the video files embedded with this plugin will play on iOS devices
* Works on all major browsers - IE7, IE8, IE9, Safari, Firefox, Chrome
* The video player is responsive.
* Player can be used to embed the video files on your WordPress posts or pages
* If you are selling video files from your site then you can use this plugin to offer a preview
* Add the video player to any post/page using shortcode
* Use autoplay option to play an video file as soon as the page loads
* You can play unlimited video
* User friendly interface
* Powered by html5 

= Pro Version Features =

What's New in PRO ?

- Color changing Option.
- Add Videos from external source such as Amazon S3 / other hosts.
- Support Multiple Subtitle
- Video Quality Switcher 
- Increase Page load speed by changing Preload option. 
- Added Restart, Fast forward, Rewind button 
- No ads
- Show / Hide download button
- Show / Hide Every button and controls 
- Control Video speed And Quality Like YouTube
- Added Shortcode Generator in text editor of post / Page

Get The PRO here:  [BUY The PRO Version ](https://bit.ly/2U9knhp "BUY NOW") 

= Feedback = 
Liked that plugin? Hate it? Want a new feature?  [Send me some feedback](mailto:abuhayat.du@gmail.com "Send feedback")  

= Known Issues =
[Click Here to see or file a new Known Issue.](https://docs.google.com/spreadsheets/d/1YbFQVwy-22aEBFZvvsPBIgeI5dqrTFVHJ8CSwz2EOL0/edit?usp=sharing "Known issues")  


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use shortcode in page, post or in widgets.
4. If you want video in your theme php file, Place `<?php echo do_shortcode('YOUR_SHORTCODE'); ?>` in your templates

== Known Issues ==
- [Click Here to see or file a new known issue.](https://docs.google.com/spreadsheets/d/1tYV6VqBbzxdxZutp7C21MCaDrt01pIg1D_t6G2KMR0U/edit?usp=sharing "Known issues")  

== Frequently Asked Questions ==

= How do I install this plugin? =

You can install as others regular wordpress plugin. No different way. Please see on installation tab.

= What Video type can i play? =

You can play mp4, ogg video file.

= How many player i can publish in my site? =

You can publish unlimited video with unlimited player.



== Screenshots ==

1. Sidebar menu
2. Player configuration
3. UI

== Changelog ==

= 1.0 =
* Initial Release

= 1.1 =
* Fix playre position issue

= 1.2 =
* Add modern player skin 
* Improved performance

= 1.3 =
* Add support of Gutenberg Block

= 1.4 =
* Fix Volume issue
* Enable Direct Download with file name.
* Improved performance
