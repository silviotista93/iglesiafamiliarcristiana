<?php

if(!defined('ABSPATH'))
	return;

?><div class="notice notice-warning wpgmza-open-layers-feature-unavailable" style="display: none;">
	<p>
		<?php
		_e('Not available while using the OpenLayers engine.', 'wp-google-maps');
		?>
	</p>
</div>